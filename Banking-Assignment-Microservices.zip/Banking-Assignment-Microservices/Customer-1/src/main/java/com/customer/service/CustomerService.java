package com.customer.service;

import java.util.List;

import com.customer.model.Customer;

public interface CustomerService{

	public List<Customer> getAllCustomer();
	
	public Customer addCustomer(Customer customer);
	
	public Customer updateCustomer(Customer customer,int id);
	
	public Customer getCustomer(int id);
	
	public void deleteCustomer(int id);
}
