package com.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.model.Customer;
import com.customer.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;

	@GetMapping("/")
	public String find()
	{
		return "This is Customer Management";
	}
	@GetMapping("/show")
	public List<Customer> getCustomers()
	{
		return this.customerService.getAllCustomer();
	}
	@GetMapping("/show/{Id}")
	public Customer getCustomer(@PathVariable int id)
	{
		return this.customerService.getCustomer(id);
		
	}
	@PostMapping("/")
	public Customer addCustomer(@RequestBody Customer cus)
	{
		return this.customerService.addCustomer(cus);
	}
	@PutMapping("/{Id}")
	public Customer updateCustomer(@RequestBody Customer cus,@PathVariable int id)
	{
		return this.customerService.updateCustomer(cus, id);
	}
	@DeleteMapping("/{Id}")
	public ResponseEntity<HttpStatus> deleteCustomer(@PathVariable int id)
	{
		try {
			this.customerService.deleteCustomer(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
