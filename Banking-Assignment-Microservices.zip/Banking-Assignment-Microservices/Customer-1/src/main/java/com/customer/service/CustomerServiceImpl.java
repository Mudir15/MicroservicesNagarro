package com.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.dao.CustomerDao;
import com.customer.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerDao customerDao;
	
	public List<Customer> getAllCustomer()
	{
		return customerDao.findAll();
	}
	public Customer addCustomer(Customer customer)
	{
		customerDao.save(customer);
		return customer;
	}
	//update del single customer
	public Customer updateCustomer(Customer customer,int id)
	{
		Customer existingCustomer=customerDao.findById(id).orElse(null);
		if(existingCustomer==null)
			System.out.println("Customer with id"+id+"not found!");
		customer.setCustomerId(id);
		customerDao.save(customer);
		return customer;
	}
	public void deleteCustomer(int id)
	{
		Customer existingCustomer=customerDao.findById(id).orElse(null);
		if(existingCustomer==null)
			System.out.println("Customer with id"+id+"not found!");
		customerDao.deleteById(id);
	}
	public Customer getCustomer(int id)
	{
		Customer cus=customerDao.findById(id).orElse(null);
		
		return cus;
	}
}
