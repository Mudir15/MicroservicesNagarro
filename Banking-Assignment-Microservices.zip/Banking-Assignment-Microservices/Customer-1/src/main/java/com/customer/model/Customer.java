package com.customer.model;

import jakarta.persistence.Id;

import jakarta.persistence.Entity;


@Entity
public class Customer {

	@Id
	private int customerId;
	private Long accountNo;
	private String name;
	private String email;
	private String password;
	private float balance;
	public Customer(int customerId, Long accountNo, String name, String email,String password, float balance) {
		super();
		this.customerId = customerId;
		this.accountNo = accountNo;
		this.name = name;
		this.email = email;
		this.password=password;
		this.balance = balance;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	
}
