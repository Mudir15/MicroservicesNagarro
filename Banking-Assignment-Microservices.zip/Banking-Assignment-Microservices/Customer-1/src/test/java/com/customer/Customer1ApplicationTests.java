package com.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Customer1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
