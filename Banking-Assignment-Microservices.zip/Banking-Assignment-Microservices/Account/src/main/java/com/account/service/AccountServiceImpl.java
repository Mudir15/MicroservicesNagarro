package com.account.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.dao.AccountDao;
import com.account.model.Account;

@Service
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountDao accountDao;

	@Override
	public Account addMoney(Account account, int id, float money) {
		// TODO Auto-generated method stub
		Account existingAccount=accountDao.findById(id).orElse(null);
		if(existingAccount.getEmail().equals(account.getEmail()) && existingAccount.getPassword().equals(account.getPassword()))
		{
		float balance=existingAccount.getBalance();
		balance=balance+money;
		existingAccount.setBalance(balance);
		}
		return existingAccount;
	}

	@Override
	public Account withdrawMoney(Account account, int id, float money) {
		// TODO Auto-generated method stub
		Account existingAccount=accountDao.findById(id).orElse(null);
		if(existingAccount.getEmail().equals(account.getEmail()) && existingAccount.getPassword().equals(account.getPassword()))
		{
			float balance=existingAccount.getBalance();
			if(balance>money) {
				balance=balance-money;
				existingAccount.setBalance(balance);
			}
			else
				System.out.println("Insufficient Balance");
		}
		return existingAccount;
	}

	@Override
	public Account getDetails(int id) {
		// TODO Auto-generated method stub
		Account account=accountDao.findById(id).orElse(null);
		return account;
	}

	@Override
	public void deleteAccount(int id) {
		// TODO Auto-generated method stub
		Account existingAccount=accountDao.findById(id).orElse(null);
		if(existingAccount==null)
			System.out.println("Customer with id"+id+"not found!");
		accountDao.deleteById(id);
	}
	
	
}
