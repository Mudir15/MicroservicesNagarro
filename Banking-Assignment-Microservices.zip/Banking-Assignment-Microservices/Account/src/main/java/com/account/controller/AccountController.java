package com.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.account.model.Account;
import com.account.service.AccountService;

@RestController
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	public AccountService accountService;
	
	@GetMapping("/")
	public String find()
	{
		return "This is Account Management";
	}
	@GetMapping("/show/{Id}")
	public Account getAccount(@PathVariable int id)
	{
		return this.accountService.getDetails(id);
	}
	@PostMapping("/addMoney/{Id}/{Money}")
	public Account addMoney(@RequestBody Account account,@PathVariable int id,@PathVariable float money)
	{
		return this.addMoney(account, id, money);
	}
	@PostMapping("/withdrawMoney/{Id}/{Money}")
	public Account withdrawMoney(@RequestBody Account account,@PathVariable int id,@PathVariable float money)
	{
		return this.withdrawMoney(account, id, money);
	}
	@DeleteMapping("/{Id}")
	public ResponseEntity<HttpStatus> deleteCustomer(@PathVariable int id)
	{
		try {
			this.accountService.deleteAccount(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
