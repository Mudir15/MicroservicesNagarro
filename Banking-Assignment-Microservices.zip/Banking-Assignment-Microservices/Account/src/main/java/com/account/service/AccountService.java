package com.account.service;

import com.account.model.Account;

public interface AccountService {

	public Account addMoney(Account account,int id,float money);
	
	public Account withdrawMoney(Account account, int id, float money);
	
	public Account getDetails(int id);
	
	public void deleteAccount(int id);
}
